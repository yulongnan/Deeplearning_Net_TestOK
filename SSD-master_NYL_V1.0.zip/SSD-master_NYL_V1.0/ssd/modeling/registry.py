from ssd.utils.registry import Registry

BACKBONES = Registry()
BOX_HEADS = Registry()
BOX_PREDICTORS = Registry()
